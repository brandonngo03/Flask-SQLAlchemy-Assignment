# TODO - Create SQLAlchemy DB and Movie model
